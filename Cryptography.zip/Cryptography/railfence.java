import java.util.Scanner;

public class railfence {
    public static String encryptRailFence(String text, int key) {
        char rail[][] = new char[key][text.length()];
        for (int i = 0; i < key; i++)
            for (int j = 0; j < text.length(); j++)
                rail[i][j] = '\n';

        boolean dir_down = false;
        int row = 0, col = 0;

        for (int i = 0; i < text.length(); i++) {
            if (row == 0 || row == key - 1)dir_down = !dir_down;
            
            rail[row][col++] = text.charAt(i);

            if (dir_down)
                row++;
            else
                row--;
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < key; i++)
            for (int j = 0; j < text.length(); j++)
                if (rail[i][j] != '\n')
                    result.append(rail[i][j]);
        return result.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the text to be encrypted:");
        String text = sc.nextLine();
        System.out.println("Enter the number of rails:");
        int key = sc.nextInt();

        String cipher = encryptRailFence(text, key);
        System.out.println("Encrypted Text: " + cipher);

        sc.close();
    }
}
