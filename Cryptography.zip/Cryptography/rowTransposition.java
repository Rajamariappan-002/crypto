import java.util.Arrays;
import java.util.Scanner;

public class rowTransposition {
    public static String encrypt(String text, String key) {
        int[] keyOrder = getKeyOrder(key);
        int rowLength = key.length();
        int numRows = (int) Math.ceil((double) text.length() / rowLength);

        char[][] grid = new char[numRows][rowLength];
        for (int i = 0, k = 0; i < numRows; i++) {
            for (int j = 0; j < rowLength; j++) {
                if (k < text.length()) {
                    grid[i][j] = text.charAt(k++);
                } else {
                    grid[i][j] = 'X'; 
                }
            }
        }

        StringBuilder cipherText = new StringBuilder();
        for (int i = 0; i < rowLength; i++) {
            int col = keyOrder[i];
            for (int j = 0; j < numRows; j++) {
                cipherText.append(grid[j][col]);
            }
        }

        return cipherText.toString();
    }

    private static int[] getKeyOrder(String key) {
        int[] keyOrder = new int[key.length()];
        Character[] keyChars = new Character[key.length()];
        for (int i = 0; i < key.length(); i++) {
            keyChars[i] = key.charAt(i);
        }
        Arrays.sort(keyChars);
        for (int i = 0; i < key.length(); i++) {
            keyOrder[i] = key.indexOf(keyChars[i]);
        }
        return keyOrder;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the text to be encrypted:");
        String text = sc.nextLine().toUpperCase().replaceAll("\\s+", "");
        System.out.println("Enter the key:");
        String key = sc.nextLine().toUpperCase();

        String cipher = encrypt(text, key);
        System.out.println("Encrypted Text: " + cipher);

        sc.close();
    }
}
