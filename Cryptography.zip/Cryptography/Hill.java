import java.util.Scanner;

public class Hill {

    // Function to multiply two matrices
    public static int[] multiplyMatrices(int[][] keyMatrix, int[] messageVector, int size) {
        int[] resultVector = new int[size];
        for (int i = 0; i < size; i++) {
            resultVector[i] = 0;
            for (int j = 0; j < size; j++) {
                resultVector[i] += keyMatrix[i][j] * messageVector[j];
            }
            resultVector[i] %= 26; // Mod 26 for alphabetic range
        }
        return resultVector;
    }

    // Function to encrypt the message using Hill Cipher
    public static String encryptMessage(String message, int[][] keyMatrix, int size) {
        // Pad the message with 'X' to make it divisible by the matrix size
        while (message.length() % size != 0) {
            message += 'X';
        }

        StringBuilder encryptedMessage = new StringBuilder();

        // Process the message in blocks of the matrix size
        for (int i = 0; i < message.length(); i += size) {
            int[] messageVector = new int[size];
            for (int j = 0; j < size; j++) {
                messageVector[j] = message.charAt(i + j) - 'A'; // Convert character to integer (0-25)
            }

            // Multiply the key matrix with the message vector
            int[] resultVector = multiplyMatrices(keyMatrix, messageVector, size);

            // Convert back to characters
            for (int value : resultVector) {
                encryptedMessage.append((char) (value + 'A'));
            }
        }

        return encryptedMessage.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input message
        System.out.print("Enter the message (uppercase letters only): ");
        String message = scanner.nextLine().toUpperCase().replaceAll("[^A-Z]", "");

        // Input matrix size
        System.out.print("Enter the size of the key matrix (n x n): ");
        int size = scanner.nextInt();

        // Input the key matrix
        System.out.println("Enter the key matrix (row by row):");
        int[][] keyMatrix = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                keyMatrix[i][j] = scanner.nextInt();
            }
        }

        // Encrypt the message
        String encryptedMessage = encryptMessage(message, keyMatrix, size);

        // Display the encrypted message
        System.out.println("Encrypted Message: " + encryptedMessage);

        scanner.close();
    }
}
