import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class MD5Hash {

    public static String getMD5Hash(String input) {
        try {
            // Create an instance of MessageDigest with MD5 algorithm
            MessageDigest md = MessageDigest.getInstance("MD5");

            // Update the digest with the byte array of the input string
            md.update(input.getBytes());

            // Perform the hash computation and get the byte array of the hash
            byte[] digest = md.digest();

            // Convert the byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : digest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0'); // Pad with a leading zero if needed
                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 algorithm not found!", e);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input string from the user
        System.out.print("Enter the string to hash with MD5: ");
        String input = scanner.nextLine();

        // Compute and display the MD5 hash
        String md5Hash = getMD5Hash(input);
        System.out.println("MD5 Hash: " + md5Hash);

        scanner.close();
    }
}
