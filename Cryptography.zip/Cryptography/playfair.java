import java.util.Scanner;

public class playfair {
    private static char[][] charTable;
    private static String key;

 
    private static void createTable(String key) {
        charTable = new char[5][5];
        boolean[] flags = new boolean[26];
        int k = 0;
        key = key.toUpperCase().replace("J", "I");

      
        for (char c : key.toCharArray()) {
            if (!flags[c - 'A'] && c >= 'A' && c <= 'Z') {
                charTable[k / 5][k % 5] = c;
                flags[c - 'A'] = true;
                k++;
            }
        }


        for (char c = 'A'; c <= 'Z'; c++) {
            if (c == 'J') continue; 
            if (!flags[c - 'A']) {
                charTable[k / 5][k % 5] = c;
                flags[c - 'A'] = true;
                k++;
            }
        }
    }

    private static String prepareText(String input) {
        input = input.toUpperCase().replace("J", "I").replaceAll("[^A-Z]", "");
        StringBuilder sb = new StringBuilder(input);

        for (int i = 0; i < sb.length() - 1; i += 2) {
            if (sb.charAt(i) == sb.charAt(i + 1)) {
                sb.insert(i + 1, 'X');
            }
        }

        if (sb.length() % 2 != 0) {
            sb.append('X');
        }
        return sb.toString();
    }

    private static String encrypt(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i += 2) {
            sb.append(encryptPair(input.charAt(i), input.charAt(i + 1)));
        }
        return sb.toString();
    }

    private static String encryptPair(char a, char b) {
        int[] posA = findPosition(a);
        int[] posB = findPosition(b);

        if (posA[0] == posB[0]) {
            return "" + charTable[posA[0]][(posA[1] + 1) % 5] + charTable[posB[0]][(posB[1] + 1) % 5];
        }
     
        else if (posA[1] == posB[1]) {
            return "" + charTable[(posA[0] + 1) % 5][posA[1]] + charTable[(posB[0] + 1) % 5][posB[1]];
        }
      
        else {
            return "" + charTable[posA[0]][posB[1]] + charTable[posB[0]][posA[1]];
        }
    }

    private static int[] findPosition(char c) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (charTable[i][j] == c) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter key: ");
        key = sc.nextLine();
        createTable(key);

        System.out.print("Enter text to encrypt: ");
        String input = sc.nextLine();
        input = prepareText(input);

        String cipherText = encrypt(input);
        System.out.println("Ciphertext: " + cipherText);

        sc.close();
    }
}
