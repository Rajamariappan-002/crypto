import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class SHAHash {

    public static String getSHA256Hash(String input) {
        try {
            // Create an instance of MessageDigest with SHA-256 algorithm
            MessageDigest sha = MessageDigest.getInstance("SHA-256");

            // Update the digest with the byte array of the input string
            sha.update(input.getBytes());

            // Perform the hash computation and get the byte array of the hash
            byte[] digest = sha.digest();

            // Convert the byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : digest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0'); // Pad with a leading zero if needed
                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found!", e);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input string from the user
        System.out.print("Enter the string to hash with SHA-256: ");
        String input = scanner.nextLine();

        // Compute and display the SHA-256 hash
        String shaHash = getSHA256Hash(input);
        System.out.println("SHA-256 Hash: " + shaHash);

        scanner.close();
    }
}

