import java.util.Scanner;

public class ModularExponentiationWithEuler {

    public static int eulerTotient(int n) {
        int result = n;
        for (int p = 2; p * p <= n; p++) {
            if (n % p == 0) {
                while (n % p == 0) {
                    n /= p;
                }
                result -= result / p;
            }
        }
        if (n > 1) {
            result -= result / n;
        }
        return result;
    }

    public static int modularExponentiation(int base, int exp, int m) {
        int result = 1;
        base = base % m;
        while (exp > 0) {
            if ((exp & 1) == 1) {
                result = (result * base) % m;
            }
            exp >>= 1;
            base = (base * base) % m;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the base (a): ");
        int a = scanner.nextInt();
        System.out.print("Enter the exponent (b): ");
        int exponent = scanner.nextInt();
        System.out.print("Enter the modulus (m): ");
        int modulus = scanner.nextInt();
        
        int phiModulus = eulerTotient(modulus);
        int reducedExponent = exponent % phiModulus;
        
        int result = modularExponentiation(a, reducedExponent, modulus);
        System.out.println(a + "^" + exponent + " mod " + modulus + " = " + result);
        
        scanner.close();
    }
}
