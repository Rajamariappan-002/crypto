import java.util.Scanner;

public class EuclideanAlgorithm {

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static int extendedGCD(int a, int b) {
        if (a == 0) {
            return b;
        }
        return extendedGCD(b % a, a);
    }

    public static int modularInverse(int a, int m) {
        int g = gcd(a, m);
        if (g != 1) {
            throw new ArithmeticException("Inverse doesn't exist");
        } else {
            return extendedGCD(a, m);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the first integer (a): ");
        int a = scanner.nextInt();
        System.out.print("Enter the second integer (b): ");
        int b = scanner.nextInt();
        
        int gcdValue = gcd(a, b);
        System.out.println("GCD of " + a + " and " + b + " = " + gcdValue);
        
        System.out.print("Enter the integer for modular inverse (a): ");
        a = scanner.nextInt();
        System.out.print("Enter the modulus (m): ");
        int m = scanner.nextInt();
        
        try {
            int inverse = modularInverse(a, m);
            System.out.println("Modular Inverse of " + a + " mod " + m + " = " + inverse);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
        
        scanner.close();
    }
}
