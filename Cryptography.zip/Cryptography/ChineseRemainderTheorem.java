import java.util.Scanner;

public class ChineseRemainderTheorem {

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    public static int chineseRemainder(int[] a, int[] m) {
        int prod = 1;
        for (int mi : m) {
            prod *= mi;
        }

        int result = 0;
        for (int i = 0; i < a.length; i++) {
            int ni = prod / m[i];
            result += a[i] * modularInverse(ni, m[i]) * ni;
        }
        return result % prod;
    }

    public static int modularInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return 1; // If no inverse exists, return 1 (this should not happen if m is prime)
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of equations: ");
        int n = scanner.nextInt();

        int[] a = new int[n];
        int[] m = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter the remainder a[" + i + "]: ");
            a[i] = scanner.nextInt();
            System.out.print("Enter the modulus m[" + i + "]: ");
            m[i] = scanner.nextInt();
        }

        int result = chineseRemainder(a, m);
        System.out.println("The solution is: " + result);

        scanner.close();
    }
}
