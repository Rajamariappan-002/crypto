file:///C:/Users/Admin/Desktop/Cryptography/ModularExponentiationWithEuler.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
offset: 613
uri: file:///C:/Users/Admin/Desktop/Cryptography/ModularExponentiationWithEuler.java
text:
```scala
import java.util.Scanner;

public class ModularExponentiationWithEuler {

    public static int eulerTotient(int n) {
        int result = n;
        for (int p = 2; p * p <= n; p++) {
            if (n % p == 0) {
                while (n % p == 0) {
                    n /= p;
                }
                result -= result / p;
            }
        }
        if (n > 1) {
            result -= result / n;
        }
        return result;
    }

    public static int modularExponentiation(int base, int exp, int m) {
        int result = 1;
        base = base % m;
        while @@(exp > 0) {
            if ((exp & 1) == 1) {
                result = (result * base) % m;
            }
            exp >>= 1;
            base = (base * base) % m;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the base (a): ");
        int a = scanner.nextInt();
        System.out.print("Enter the exponent (b): ");
        int exponent = scanner.nextInt();
        System.out.print("Enter the modulus (m): ");
        int modulus = scanner.nextInt();
        
        int phiModulus = eulerTotient(modulus);
        int reducedExponent = exponent % phiModulus;
        
        int result = modularExponentiation(a, reducedExponent, modulus);
        System.out.println(a + "^" + exponent + " mod " + modulus + " = " + result);
        
        scanner.close();
    }
}

```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.HoverProvider$.hover(HoverProvider.scala:36)
	scala.meta.internal.pc.ScalaPresentationCompiler.hover$$anonfun$1(ScalaPresentationCompiler.scala:389)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator