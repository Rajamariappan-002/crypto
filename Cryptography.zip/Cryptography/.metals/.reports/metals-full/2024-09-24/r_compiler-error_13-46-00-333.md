file:///C:/Users/Admin/Desktop/Cryptography/EuclideanAlgorithm.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
offset: 27
uri: file:///C:/Users/Admin/Desktop/Cryptography/EuclideanAlgorithm.java
text:
```scala
import java.util.Scanner;
@@
public class EuclideanAlgorithm {

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static int extendedGCD(int a, int b) {
        if (a == 0) {
            return b;
        }
        return extendedGCD(b % a, a);
    }

    public static int modularInverse(int a, int m) {
        int g = gcd(a, m);
        if (g != 1) {
            throw new ArithmeticException("Inverse doesn't exist");
        } else {
            return extendedGCD(a, m);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the first integer (a): ");
        int a = scanner.nextInt();
        System.out.print("Enter the second integer (b): ");
        int b = scanner.nextInt();
        
        int gcdValue = gcd(a, b);
        System.out.println("GCD of " + a + " and " + b + " = " + gcdValue);
        
        System.out.print("Enter the integer for modular inverse (a): ");
        a = scanner.nextInt();
        System.out.print("Enter the modulus (m): ");
        int m = scanner.nextInt();
        
        try {
            int inverse = modularInverse(a, m);
            System.out.println("Modular Inverse of " + a + " mod " + m + " = " + inverse);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
        
        scanner.close();
    }
}

```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.HoverProvider$.hover(HoverProvider.scala:36)
	scala.meta.internal.pc.ScalaPresentationCompiler.hover$$anonfun$1(ScalaPresentationCompiler.scala:389)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator