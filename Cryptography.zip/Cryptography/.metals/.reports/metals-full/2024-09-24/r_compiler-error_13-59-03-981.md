file:///C:/Users/Admin/Desktop/Cryptography/Chinese.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
offset: 1613
uri: file:///C:/Users/Admin/Desktop/Cryptography/Chinese.java
text:
```scala
import java.util.Scanner;

public class ChineseRemainderTheorem {

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    public static int chineseRemainder(int[] a, int[] m) {
        int prod = 1;
        for (int mi : m) {
            prod *= mi;
        }

        int result = 0;
        for (int i = 0; i < a.length; i++) {
            int ni = prod / m[i];
            result += a[i] * modularInverse(ni, m[i]) * ni;
        }
        return result % prod;
    }

    public static int modularInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return 1; // If no inverse exists, return 1 (this should not happen if m is prime)
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of equations: ");
        int n = scanner.nextInt();

        int[] a = new int[n];
        int[] m = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter the remainder a[" + i + "]: ");
            a[i] = scanner.nextInt();
            System.out.print("Enter the modulus m[" + i + "]: ");
            m[i] = scanner.nextInt();
        }

        int result = chineseRemainder(a, m);
        System.out.printl@@n("The solution is: " + result);

        scanner.close();
    }
}

```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.HoverProvider$.hover(HoverProvider.scala:36)
	scala.meta.internal.pc.ScalaPresentationCompiler.hover$$anonfun$1(ScalaPresentationCompiler.scala:389)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator