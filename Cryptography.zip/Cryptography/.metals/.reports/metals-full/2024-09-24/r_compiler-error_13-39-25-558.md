file:///C:/Users/Admin/Desktop/Cryptography/rowTransposition.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
uri: file:///C:/Users/Admin/Desktop/Cryptography/rowTransposition.java
text:
```scala
import java.util.Arrays;
import java.util.Scanner;

public class rowTransposition {
    public static String encrypt(String text, String key) {
        int[] keyOrder = getKeyOrder(key);
        int rowLength = key.length();
        int numRows = (int) Math.ceil((double) text.length() / rowLength);

        char[][] grid = new char[numRows][rowLength];
        for (int i = 0, k = 0; i < numRows; i++) {
            for (int j = 0; j < rowLength; j++) {
                if (k < text.length()) {
                    grid[i][j] = text.charAt(k++);
                } else {
                    grid[i][j] = 'X'; 
                }
            }
        }

        StringBuilder cipherText = new StringBuilder();
        for (int i = 0; i < rowLength; i++) {
            int col = keyOrder[i];
            for (int j = 0; j < numRows; j++) {
                cipherText.append(grid[j][col]);
            }
        }

        return cipherText.toString();
    }

    private static int[] getKeyOrder(String key) {
        int[] keyOrder = new int[key.length()];
        Character[] keyChars = new Character[key.length()];
        for (int i = 0; i < key.length(); i++) {
            keyChars[i] = key.charAt(i);
        }
        Arrays.sort(keyChars);
        for (int i = 0; i < key.length(); i++) {
            keyOrder[i] = key.indexOf(keyChars[i]);
        }
        return keyOrder;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the text to be encrypted:");
        String text = sc.nextLine().toUpperCase().replaceAll("\\s+", "");
        System.out.println("Enter the key:");
        String key = sc.nextLine().toUpperCase();

        String cipher = encrypt(text, key);
        System.out.println("Encrypted Text: " + cipher);

        sc.close();
    }
}

```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.WithCompilationUnit.<init>(WithCompilationUnit.scala:28)
	scala.meta.internal.pc.SimpleCollector.<init>(PcCollector.scala:373)
	scala.meta.internal.pc.PcSemanticTokensProvider$Collector$.<init>(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.Collector$lzyINIT1(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.Collector(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.provide(PcSemanticTokensProvider.scala:90)
	scala.meta.internal.pc.ScalaPresentationCompiler.semanticTokens$$anonfun$1(ScalaPresentationCompiler.scala:117)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator