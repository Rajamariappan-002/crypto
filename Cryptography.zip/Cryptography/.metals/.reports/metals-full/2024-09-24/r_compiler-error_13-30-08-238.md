file:///C:/Users/Admin/Desktop/Cryptography/EulerTott.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
offset: 332
uri: file:///C:/Users/Admin/Desktop/Cryptography/EulerTott.java
text:
```scala
import java.util.Scanner;

public class EulerTott {

    // Function to compute Euler's Totient function
    public static int eulerTotient(int n) {
        int result = n; // Initialize result as n

        // Check for each number from 2 to sqrt(n)
        for (int p = 2; p * p <= n; p++) {
            // Check if p is@@ a divisor of n
            if (n % p == 0) {
                // If yes, then it's a prime factor
                while (n % p == 0) {
                    n /= p;
                }
                result -= result / p; // Reduce result by the fraction
            }
        }

        // If n has a prime factor greater than sqrt(n)
        if (n > 1) {
            result -= result / n;
        }

        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        int n = scanner.nextInt();

        int result = eulerTotient(n);
        System.out.println("Euler's Totient function φ(" + n + ") = " + result);

        scanner.close();
    }
}

```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.HoverProvider$.hover(HoverProvider.scala:36)
	scala.meta.internal.pc.ScalaPresentationCompiler.hover$$anonfun$1(ScalaPresentationCompiler.scala:389)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator