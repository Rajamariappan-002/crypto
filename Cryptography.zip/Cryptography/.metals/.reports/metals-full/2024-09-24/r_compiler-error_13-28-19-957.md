file:///C:/Users/Admin/Desktop/Cryptography/cipher.java
### java.util.NoSuchElementException: next on empty iterator

occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 3.3.3
Classpath:
<HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala3-library_3\3.3.3\scala3-library_3-3.3.3.jar [exists ], <HOME>\AppData\Local\Coursier\cache\v1\https\repo1.maven.org\maven2\org\scala-lang\scala-library\2.13.12\scala-library-2.13.12.jar [exists ]
Options:



action parameters:
offset: 599
uri: file:///C:/Users/Admin/Desktop/Cryptography/cipher.java
text:
```scala
import java.util.*;


class cipher{

    private static String encrypted(String text, int key){
        StringBuilder encr = new StringBuilder();

        for(int i=0;i<text.length();i++){
            if(Character.isAlphabetic(text.charAt(i))){
                char a = (Character.isUpperCase(text.charAt(i))) ? 'A' : 'a';
                int num = (((text.charAt(i) - a) + key) % 26 + 26) % 26 + a; 
                char b = (char)num;
                encr.append(b);
            }else{
                encr.append(text.charAt(i));
            }
        }
        return encr.toSt@@ring();
    }

    private static void decrypt(String text){
        for(int i=1;i<26;i++)System.out.println("Decrypted at key "+i+" : "+encrypted(text, -i));
    }
    public static void main(String args[]){
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the text to be encrypted:");
        String text = s.nextLine();
        System.out.println("Enter the key:");
        int key = s.nextInt();
        String decrypted = encrypted(text, key);
        System.out.println("Encrypted text : "+decrypted);
        System.out.println("Decrypted text are below for each key : ");
        decrypt(decrypted);
   }
}




```



#### Error stacktrace:

```
scala.collection.Iterator$$anon$19.next(Iterator.scala:973)
	scala.collection.Iterator$$anon$19.next(Iterator.scala:971)
	scala.collection.mutable.MutationTracker$CheckedIterator.next(MutationTracker.scala:76)
	scala.collection.IterableOps.head(Iterable.scala:222)
	scala.collection.IterableOps.head$(Iterable.scala:222)
	scala.collection.AbstractIterable.head(Iterable.scala:933)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:168)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.HoverProvider$.hover(HoverProvider.scala:36)
	scala.meta.internal.pc.ScalaPresentationCompiler.hover$$anonfun$1(ScalaPresentationCompiler.scala:389)
```
#### Short summary: 

java.util.NoSuchElementException: next on empty iterator