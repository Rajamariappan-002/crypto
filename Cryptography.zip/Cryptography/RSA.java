import java.math.BigInteger;
import java.util.Scanner;

public class RSA {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        BigInteger p = new BigInteger("61"); 
        BigInteger q = new BigInteger("53"); 

        BigInteger n = p.multiply(q);
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

  
        BigInteger e = new BigInteger("17");    


        BigInteger d = e.modInverse(phi);


        System.out.print("Enter the message to be encrypted (as an integer): ");
        BigInteger msg = scanner.nextBigInteger();

        
        BigInteger ciphertext = msg.modPow(e, n);
        System.out.println("Encrypted Message: " + ciphertext);


        BigInteger decryptedMsg = ciphertext.modPow(d, n);
        System.out.println("Decrypted Message: " + decryptedMsg);

        if (msg.equals(decryptedMsg)) {
            System.out.println("Decryption successful! The decrypted message matches the original message.");
        } else {
            System.out.println("Decryption failed! The decrypted message does not match the original message.");
        }

        scanner.close();
    }
}
