import java.util.Scanner;

public class EulersTheorem {

    
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    
    public static int eulerTotient(int n) {
        int count = 0;
        for (int i = 1; i < n; i++) {
            if (gcd(i, n) == 1) { 
                count++;
            }
        }
        return count;
    }


    public static int modularExponentiation(int a, int b, int n) {
        int result = 1;
        a = a % n; 
        while (b > 0) {
            if ((b & 1) == 1) { 
                result = (result * a) % n;
            }
            b = b >> 1; // Divide 'b' by 2
            a = (a * a) % n; // Square 'a'
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input values for 'a' and 'n'
        System.out.print("Enter the value of a: ");
        int a = scanner.nextInt();

        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

        // Calculate φ(n)
        int phiN = eulerTotient(n);
        System.out.println("Euler's Totient Function phi(" + n + ") = " + phiN);

        // Check if a and n are coprime
        if (gcd(a, n) != 1) {
            System.out.println("a and n are not coprime. Euler's theorem is not applicable.");
        } else {
            // Apply Euler's theorem
            int result = modularExponentiation(a, phiN, n);
            System.out.println("According to Euler's theorem: " + a + "^phi(" + n + ") ≡ " + result + " (mod " + n + ")");
        }

        scanner.close();
    }
}
