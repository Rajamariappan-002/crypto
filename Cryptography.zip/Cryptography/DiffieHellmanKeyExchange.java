import java.math.BigInteger;
import java.util.Scanner;

public class DiffieHellmanKeyExchange {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a prime number (p): ");
        BigInteger p = scanner.nextBigInteger();

        // Input for the base g (a primitive root modulo p)
        System.out.print("Enter a base (g): ");
        BigInteger g = scanner.nextBigInteger();

        // User A's private key
        System.out.print("Enter User A's private key: ");
        BigInteger privateKeyA = scanner.nextBigInteger();

        // User B's private key
        System.out.print("Enter User B's private key: ");
        BigInteger privateKeyB = scanner.nextBigInteger();

        // Calculate User A's public key: (g^privateKeyA) mod p
        BigInteger publicKeyA = g.modPow(privateKeyA, p);
        System.out.println("User A's public key: " + publicKeyA);

        // Calculate User B's public key: (g^privateKeyB) mod p
        BigInteger publicKeyB = g.modPow(privateKeyB, p);
        System.out.println("User B's public key: " + publicKeyB);

        // Calculate the shared secret key for User A: (publicKeyB^privateKeyA) mod p
        BigInteger sharedSecretA = publicKeyB.modPow(privateKeyA, p);
        System.out.println("User A's computed shared secret key: " + sharedSecretA);

        
        BigInteger sharedSecretB = publicKeyA.modPow(privateKeyB, p);
        System.out.println("User B's computed shared secret key: " + sharedSecretB);

       
        if (sharedSecretA.equals(sharedSecretB)) {
            System.out.println("The shared secret key is successfully generated: " + sharedSecretA);
        } else {
            System.out.println("Error: The shared secret keys do not match.");
        }

        scanner.close();
    }
}
