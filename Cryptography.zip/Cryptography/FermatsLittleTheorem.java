import java.util.Scanner;

public class FermatsLittleTheorem {

    static long modularExponentiation(long base, long exponent, long mod) {
        long result = 1;
        base = base % mod;

        while (exponent > 0) {
            if ((exponent & 1) == 1) {
                result = (result * base) % mod;
            }
            exponent = exponent >> 1;
            base = (base * base) % mod;
        }
        return result;
    }

    static boolean isPrime(long p) {
        if (p <= 1) return false;
        if (p <= 3) return true;
        if (p % 2 == 0 || p % 3 == 0) return false;

        for (long i = 5; i * i <= p; i += 6) {
            if (p % i == 0 || p % (i + 2) == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a (base): ");
        long a = scanner.nextLong();

        System.out.print("Enter p (prime number): ");
        long p = scanner.nextLong();

        if (isPrime(p)) {
            long result = modularExponentiation(a, p - 1, p);
            System.out.println(a + "^(" + (p - 1) + ") % " + p + " = " + result);
            System.out.println("According to Fermat's Little Theorem: " + result );
        } else {
            System.out.println(p + " is not a prime number.");
        }

        scanner.close();
    }
}
