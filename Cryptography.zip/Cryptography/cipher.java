import java.util.*;


class cipher{

    private static String encrypted(String text, int key){
        StringBuilder encr = new StringBuilder();

        for(int i=0;i<text.length();i++){
            if(Character.isAlphabetic(text.charAt(i))){
                char a = (Character.isUpperCase(text.charAt(i))) ? 'A' : 'a';
                int num = (((text.charAt(i) - a) + key) % 26 + 26) % 26 + a; 
                char b = (char)num;
                encr.append(b);
            }else{
                encr.append(text.charAt(i));
            }
        }
        return encr.toString();
    }

    private static void decrypt(String text){
        for(int i=1;i<26;i++)System.out.println("Decrypted at key "+i+" : "+encrypted(text, -i));
    }
    public static void main(String args[]){
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the text to be encrypted:");
        String text = s.nextLine();
        System.out.println("Enter the key:");
        int key = s.nextInt();
        String decrypted = encrypted(text, key);
        System.out.println("Encrypted text : "+decrypted);
        System.out.println("Decrypted text are below for each key : ");
        decrypt(decrypted);
        s.close();
   }
}



