import java.util.*;

class substituition{
    private static String encrypt(String text, Map<Character, Character> keys){
        StringBuilder encr = new StringBuilder();

        for(int i=0;i<text.length();i++){
            if(Character.isAlphabetic(text.charAt(i))){
                encr.append(keys.get(text.charAt(i)));
            }else encr.append(text.charAt(i));
        }

        return encr.toString();
    }

    public static void main(String args[]){
        Scanner s = new Scanner(System.in);
        Map<Character, Character> keys = new HashMap<>();
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.println("Enter the text : ");
        String text = s.nextLine();
        System.out.println("Enter the key as 26 distinct unordered alphabet : ");
        String key = s.next();

        for(int i=0;i<26;i++)keys.put(alphabet.charAt(i), key.charAt(i));

        System.out.println("Encrypted Text : "+encrypt(text.toUpperCase(), keys));
        s.close();
    }

    



}